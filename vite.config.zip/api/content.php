function updateContent($page, $section, $content, $language) {
    global $db_config;
    $pdo = new PDO("mysql:host={$db_config['host']};dbname={$db_config['dbname']}", 
                   $db_config['username'], 
                   $db_config['password']);
    
    $stmt = $pdo->prepare("INSERT INTO content (page_name, section_name, content_data, language) 
                          VALUES (?, ?, ?, ?) 
                          ON DUPLICATE KEY UPDATE content_data = ?");
    return $stmt->execute([$page, $section, $content, $language, $content]);
}