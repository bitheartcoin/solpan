import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

const setup = () => {
  try {
    console.log('🚀 Starting project setup...');

    // Install dependencies
    console.log('📦 Installing dependencies...');
    execSync('npm install', { stdio: 'inherit' });

    // Create .env file if it doesn't exist
    if (!fs.existsSync('.env')) {
      console.log('🔑 Creating .env file...');
      fs.copyFileSync('.env.example', '.env');
    }

    // Create VS Code settings directory if it doesn't exist
    const vscodePath = '.vscode';
    if (!fs.existsSync(vscodePath)) {
      fs.mkdirSync(vscodePath);
    }

    // Create VS Code settings
    const settings = {
      "editor.formatOnSave": true,
      "editor.defaultFormatter": "esbenp.prettier-vscode",
      "editor.codeActionsOnSave": {
        "source.fixAll.eslint": "explicit"
      },
      "tailwindCSS.experimental.classRegex": [
        ["cva\\(([^)]*)\\)", "[\"'`]([^\"'`]*).*?[\"'`]"]
      ]
    };

    fs.writeFileSync(
      path.join(vscodePath, 'settings.json'),
      JSON.stringify(settings, null, 2)
    );

    // Create Prettier config
    const prettierConfig = {
      "semi": true,
      "singleQuote": true,
      "tabWidth": 2,
      "trailingComma": "es5"
    };

    fs.writeFileSync(
      '.prettierrc',
      JSON.stringify(prettierConfig, null, 2)
    );

    console.log('✨ Setup complete! Please:');
    console.log('1. Install recommended VS Code extensions');
    console.log('2. Open the project in VS Code using the workspace file');
    console.log('3. Run npm run dev to start development server');

  } catch (error) {
    console.error('❌ Setup failed:', error);
    process.exit(1);
  }
};

setup();