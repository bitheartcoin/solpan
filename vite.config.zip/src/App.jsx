// File: src/App.jsx
import React, { Suspense, useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navigation from './components/Navigation';
import AdminPanel from './components/admin/AdminPanel';
import ThemeToggle from './components/ThemeToggle';
import LanguageSelector from './components/LanguageSelector';
import ProtectedRoute from './components/ProtectedRoute';
import Calculator from './components/Calculator';
import { useTranslation } from 'react-i18next';

// Page imports
const HomePage = React.lazy(() => import('./pages/HomePage'));
const SolarPanels = React.lazy(() => import('./pages/SolarPanels'));
const HeatPumps = React.lazy(() => import('./pages/HeatPumps'));
const Inverters = React.lazy(() => import('./pages/Inverters'));
const Airco = React.lazy(() => import('./pages/Airco'));
const Charging = React.lazy(() => import('./pages/Charging'));
const Isolation = React.lazy(() => import('./pages/Isolation'));
const Login = React.lazy(() => import('./pages/login'));

function App() {
  const { t } = useTranslation();
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
        <Navigation />
        <LanguageSelector />
        <ThemeToggle />

        <Suspense fallback={<div>Loading...</div>}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/solar" element={<SolarPanels />} />
            <Route path="/heatpumps" element={<HeatPumps />} />
            <Route path="/inverters" element={<Inverters />} />
            <Route path="/airco" element={<Airco />} />
            <Route path="/charging" element={<Charging />} />
            <Route path="/isolation" element={<Isolation />} />
            <Route path="/calculator" element={<Calculator />} />
            <Route path="/login" element={<Login setIsAuthenticated={setIsAuthenticated} />} />
            <Route
              path="/admin/*"
              element={
                <ProtectedRoute isAuthenticated={isAuthenticated}>
                  <AdminPanel />
                </ProtectedRoute>
              }
            />
          </Routes>
        </Suspense>
      </div>
    </BrowserRouter>
  );
}

export default App;