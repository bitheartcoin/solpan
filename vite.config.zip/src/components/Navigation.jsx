import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const Navigation = () => {
  const { t } = useTranslation();

  return (
    <nav className="fixed w-full bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="text-xl font-semibold">
            SolPan
          </Link>
          <div className="hidden md:flex space-x-4">
            <Link to="/solar" className="px-3 py-2">{t('nav.solar')}</Link>
            <Link to="/heatpumps" className="px-3 py-2">{t('nav.heatpumps')}</Link>
            <Link to="/inverters" className="px-3 py-2">{t('nav.inverters')}</Link>
            <Link to="/airco" className="px-3 py-2">{t('nav.airco')}</Link>
            <Link to="/charging" className="px-3 py-2">{t('nav.charging')}</Link>
            <Link to="/isolation" className="px-3 py-2">{t('nav.isolation')}</Link>
            <Link to="/calculator" className="px-3 py-2">{t('nav.calculator')}</Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;