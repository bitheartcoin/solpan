import React from 'react';

const ListItem = ({ children }) => {
  return (
    <div className="flex items-center space-x-3">
      <div className="w-2 h-2 bg-green-500 rounded-full" />
      <span className="text-gray-600 dark:text-gray-300">{children}</span>
    </div>
  );
};

export default ListItem;