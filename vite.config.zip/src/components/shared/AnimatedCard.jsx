import React from 'react';
import { motion } from 'framer-motion';

const AnimatedCard = ({ children, custom, variants, className = '' }) => {
  return (
    <motion.div
      custom={custom}
      variants={variants}
      className={`bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 transform hover:scale-105 transition-transform duration-300 ${className}`}
    >
      {children}
    </motion.div>
  );
};

export default AnimatedCard;