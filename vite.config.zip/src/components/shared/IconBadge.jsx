import React from 'react';

const IconBadge = ({ children, className = '' }) => {
  return (
    <div className={`h-16 w-16 bg-green-100 dark:bg-green-900 rounded-xl flex items-center justify-center mb-6 ${className}`}>
      {children}
    </div>
  );
};

export default IconBadge;