import React from 'react';
import { motion } from 'framer-motion';

const Loader = () => {
  return (
    <div className="fixed inset-0 bg-white dark:bg-gray-900 z-50 flex items-center justify-center">
      <motion.div
        className="flex space-x-2"
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, 180, 360],
        }}
        transition={{
          duration: 2,
          ease: "easeInOut",
          repeat: Infinity,
        }}
      >
        <div className="w-3 h-3 bg-green-500 rounded-full" />
        <div className="w-3 h-3 bg-green-600 rounded-full" />
        <div className="w-3 h-3 bg-green-700 rounded-full" />
      </motion.div>
    </div>
  );
};

export default Loader;