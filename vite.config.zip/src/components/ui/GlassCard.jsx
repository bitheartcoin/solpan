import React from 'react';
import { motion } from 'framer-motion';

const GlassCard = ({ children, delay = 0 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay }}
      className="backdrop-blur-lg bg-white/80 dark:bg-gray-900/80 rounded-3xl shadow-xl p-8 border border-white/20 hover:border-green-500/30 transition-all duration-300"
    >
      {children}
    </motion.div>
  );
};

export default GlassCard;