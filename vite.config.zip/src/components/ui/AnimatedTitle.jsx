import React from 'react';
import { motion } from 'framer-motion';

const AnimatedTitle = ({ children, className = '' }) => {
  return (
    <motion.h2
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className={`text-5xl md:text-6xl font-light bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent mb-8 ${className}`}
    >
      {children}
    </motion.h2>
  );
};

export default AnimatedTitle;