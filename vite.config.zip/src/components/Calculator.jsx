// src/components/Calculator.jsx
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';

const Calculator = () => {
  const { t } = useTranslation();
  const [consumption, setConsumption] = useState('');
  const [result, setResult] = useState(null);

  const calculate = () => {
    const yearlyConsumption = parseFloat(consumption);
    const panelOutput = 400; // Watts per panel
    const sunHours = 4; // Average daily sun hours
    
    const neededPanels = Math.ceil((yearlyConsumption * 1000) / (panelOutput * sunHours * 365));
    setResult(neededPanels);
  };

  return (
    <div className="min-h-screen p-8 bg-white dark:bg-gray-900">
      <h2 className="text-2xl mb-4">{t('calculator.title')}</h2>
      <div className="max-w-md space-y-4">
        <div>
          <label className="block mb-2">{t('calculator.consumption')}</label>
          <input
            type="number"
            value={consumption}
            onChange={(e) => setConsumption(e.target.value)}
            className="w-full p-2 border rounded"
          />
        </div>
        <button
          onClick={calculate}
          className="px-4 py-2 bg-blue-500 text-white rounded"
        >
          {t('calculator.calculate')}
        </button>
        {result && (
          <div className="mt-4 p-4 bg-gray-100 dark:bg-gray-800 rounded">
            {t('calculator.result', { panels: result })}
          </div>
        )}
      </div>
    </div>
  );
};

export default Calculator;