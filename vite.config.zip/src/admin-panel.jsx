import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';

const AdminPanel = () => {
  const { t } = useTranslation();
  const [selectedPage, setSelectedPage] = useState('home');
  const [selectedLanguage, setSelectedLanguage] = useState('en');

  return (
    <div className="min-h-screen p-8 bg-white dark:bg-gray-900">
      <h1 className="text-2xl mb-6">{t('admin.title')}</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-100 dark:bg-gray-800 p-6 rounded-lg">
          <select 
            value={selectedPage}
            onChange={(e) => setSelectedPage(e.target.value)}
            className="w-full p-2 mb-4 rounded"
          >
            <option value="home">Home</option>
            <option value="solar">Solar Panels</option>
            <option value="heatpumps">Heat Pumps</option>
            <option value="inverters">Inverters</option>
            <option value="airco">Airco</option>
            <option value="charging">Charging</option>
            <option value="isolation">Isolation</option>
          </select>

          <select 
            value={selectedLanguage}
            onChange={(e) => setSelectedLanguage(e.target.value)}
            className="w-full p-2 mb-4 rounded"
          >
            <option value="en">English</option>
            <option value="hu">Hungarian</option>
            <option value="de">German</option>
          </select>

          <textarea 
            className="w-full p-2 h-64 rounded"
            placeholder="Content..."
          />
          
          <button className="mt-4 px-4 py-2 bg-blue-500 text-white rounded">
            Save Changes
          </button>
        </div>

        <div className="bg-gray-100 dark:bg-gray-800 p-6 rounded-lg">
          <h2 className="text-xl mb-4">Media Upload</h2>
          <input 
            type="file" 
            className="mb-4"
            accept="image/*"
          />
          <div className="grid grid-cols-2 gap-4">
            {/* Image preview area */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;

// src/components/ThemeToggle.jsx
import React from 'react';

const ThemeToggle = () => {
  const toggleTheme = () => {
    document.documentElement.classList.toggle('dark');
  };

  return (
    <button 
      onClick={toggleTheme}
      className="fixed bottom-4 right-4 p-2 bg-gray-200 dark:bg-gray-700 rounded-full"
    >
      🌓
    </button>
  );
};

export default ThemeToggle;

// src/components/LanguageSelector.jsx
import React from 'react';
import { useTranslation } from 'react-i18next';

const LanguageSelector = () => {
  const { i18n } = useTranslation();

  return (
    <select 
      onChange={(e) => i18n.changeLanguage(e.target.value)}
      className="fixed top-4 right-4 p-2 rounded bg-white dark:bg-gray-800"
      value={i18n.language}
    >
      <option value="en">English</option>
      <option value="hu">Magyar</option>
      <option value="de">Deutsch</option>
    </select>
  );
};

export default LanguageSelector;