import React from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import GlassCard from '../components/ui/GlassCard';
import AnimatedTitle from '../components/ui/AnimatedTitle';

const Charging = () => {
  const { t } = useTranslation();
  const types = ['Home Charging', 'Public Charging Stations', 'Fast Charging'];

  return (
    <div className="min-h-screen relative overflow-hidden" id="charging">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-teal-50 to-cyan-100 dark:from-gray-900 dark:to-gray-800" />

      {/* Animated background shapes */}
      <motion.div
        animate={{
          scale: [1.2, 1, 1.2],
          rotate: [360, 180, 0],
        }}
        transition={{ duration: 25, repeat: Infinity }}
        className="absolute -bottom-20 -left-20 w-96 h-96 bg-cyan-400/10 rounded-full blur-3xl"
      />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <AnimatedTitle>{t('charging.title')}</AnimatedTitle>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <GlassCard delay={0.2}>
            <h2 className="text-3xl font-light text-gray-900 dark:text-white mb-6">
              {t('charging.types.title')}
            </h2>
            <div className="space-y-4 text-lg text-gray-600 dark:text-gray-300">
              {types.map((type, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-teal-500 rounded-full" />
                  <span>{type}</span>
                </div>
              ))}
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  );
};

export default Charging;
