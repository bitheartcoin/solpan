import React from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import GlassCard from '../components/ui/GlassCard';
import AnimatedTitle from '../components/ui/AnimatedTitle';

const HomePage = () => {
  const { t } = useTranslation();

  const benefits = [
    { icon: "⚡", key: "1" },
    { icon: "🌡️", key: "2" },
    { icon: "🏠", key: "3" }
  ];

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-green-50 to-emerald-100 dark:from-gray-900 dark:to-gray-800" />
      
      {/* Animated background shapes */}
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, 180, 360],
        }}
        transition={{ duration: 20, repeat: Infinity }}
        className="absolute top-20 right-20 w-96 h-96 bg-green-400/10 rounded-full blur-3xl"
      />
      <motion.div
        animate={{
          scale: [1.2, 1, 1.2],
          rotate: [360, 180, 0],
        }}
        transition={{ duration: 25, repeat: Infinity }}
        className="absolute -bottom-20 -left-20 w-96 h-96 bg-emerald-400/10 rounded-full blur-3xl"
      />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center mb-20">
          <AnimatedTitle>{t('home.title')}</AnimatedTitle>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto font-light"
          >
            {t('home.intro')}
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
          {benefits.map((benefit, i) => (
            <GlassCard key={benefit.key} delay={i * 0.2}>
              <div className="flex flex-col items-center text-center">
                <div className="text-4xl mb-6">{benefit.icon}</div>
                <h3 className="text-2xl font-light text-gray-900 dark:text-white mb-4">
                  {t(`home.benefits.${benefit.key}.title`)}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 font-light leading-relaxed">
                  {t(`home.benefits.${benefit.key}.description`)}
                </p>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HomePage;