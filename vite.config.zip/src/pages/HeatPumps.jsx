import React from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import GlassCard from '../components/ui/GlassCard';
import AnimatedTitle from '../components/ui/AnimatedTitle';

const HeatPumps = () => {
  const { t } = useTranslation();
  const brands = ['Remeha', 'LG', 'Weheat'];
  const benefits = ['item1', 'item2', 'item3'];

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-green-50 to-emerald-100 dark:from-gray-900 dark:to-gray-800" />
      
      {/* Animated background shapes */}
      <motion.div
        animate={{
          scale: [1.2, 1, 1.2],
          rotate: [360, 180, 0],
        }}
        transition={{ duration: 25, repeat: Infinity }}
        className="absolute -bottom-20 -left-20 w-96 h-96 bg-emerald-400/10 rounded-full blur-3xl"
      />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <AnimatedTitle>{t('heatpumps.title')}</AnimatedTitle>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <GlassCard delay={0.2}>
            <h2 className="text-3xl font-light text-gray-900 dark:text-white mb-6">
              {t('heatpumps.brands.title')}
            </h2>
            <div className="space-y-4 text-lg text-gray-600 dark:text-gray-300">
              {brands.map((brand) => (
                <div key={brand} className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <span>{brand}</span>
                </div>
              ))}
            </div>
          </GlassCard>

          <GlassCard delay={0.4}>
            <h2 className="text-3xl font-light text-gray-900 dark:text-white mb-6">
              {t('heatpumps.benefits.title')}
            </h2>
            <div className="space-y-4 text-lg text-gray-600 dark:text-gray-300">
              {benefits.map((item) => (
                <div key={item} className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <span>{t(`heatpumps.benefits.${item}`)}</span>
                </div>
              ))}
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  );
};

export default HeatPumps;