import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const Login = ({ setIsAuthenticated }) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [credentials, setCredentials] = useState({
    username: '',
    password: ''
  });

  const handleLogin = async (e) => {
    e.preventDefault();
    if (credentials.username === 'rh45257_admin' && credentials.password === '07230518Aa!') {
      setIsAuthenticated(true);
      navigate('/admin');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center">
      <form onSubmit={handleLogin} className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-lg">
        <h2 className="text-2xl mb-4">{t('login.title')}</h2>
        <div className="space-y-4">
          <input
            type="text"
            placeholder={t('login.username')}
            value={credentials.username}
            onChange={(e) => setCredentials(prev => ({ ...prev, username: e.target.value }))}
            className="w-full p-2 border rounded"
          />
          <input
            type="password"
            placeholder={t('login.password')}
            value={credentials.password}
            onChange={(e) => setCredentials(prev => ({ ...prev, password: e.target.value }))}
            className="w-full p-2 border rounded"
          />
          <button type="submit" className="w-full p-2 bg-blue-500 text-white rounded">
            {t('login.submit')}
          </button>
        </div>
      </form>
    </div>
  );
};

export default Login;