<?php
// config/database.php
$db_config = [
    'host' => 'localhost:3306',
    'dbname' => 'rh45257_solar',
    'username' => 'rh45257_admin',
    'password' => '07230518Aa!'
];